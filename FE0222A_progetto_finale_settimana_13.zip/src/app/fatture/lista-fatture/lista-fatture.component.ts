 import { Component, OnInit } from '@angular/core';
import { Fattura } from 'src/app/interface/fattura';
import { FattureService } from 'src/app/service/fatture.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-lista-fatture',
  templateUrl: './lista-fatture.component.html',
  styleUrls: ['./lista-fatture.component.scss']
})
export class ListaFattureComponent implements OnInit {
	idCliente!: number;
	page!: number;
	pageSize!: number;
	response: any;
	fatture!: Fattura[];
  constructor(private fattureSrv: FattureService, private router: Router, private route: ActivatedRoute, private authSrv: AuthService) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
			this.idCliente = +params['id'];
			console.log(this.idCliente);
			this.upload();
		});
  }

  upload(){
    if(this.idCliente){
      this.fattureSrv.getByClienti(this.idCliente,0).subscribe(ic => {
        this.response = ic;
        this.fatture = ic.content;
      })
    }else {
      this.fattureSrv.get(0).subscribe(ic => {
        this.response = ic;
        this.fatture = ic.content;
      })
    }
  }

  changePage(p:number){
    if (this.idCliente){
      this.fattureSrv.getByClienti(this.idCliente,p).subscribe(ic =>{
        this.response = ic;
        this.fatture = ic.content;
      })
    }else {this.fattureSrv.get(p).subscribe(ic => {
      this.response = ic;
      this.fatture = ic.content;
    })}
  }

  Ondelete(name:number, id:number, i:number){
    this.fattureSrv.delete(id).subscribe(d => {
      this.fatture.splice(i,1)
    })
  }

  counter (i:number){
    return new Array(i);
  }

  logout(){
    this.authSrv.logout()

  }
}


