import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../service/auth.service';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  form!: FormGroup;
  user = {username: '', password: '', email: '', role: ['']};

  constructor(private authSrv: AuthService, private router: Router, private fb: FormBuilder) {}

  ngOnInit(): void {
this.signupForm();
  }

  signup(dataForm:{value:{roles: any; username: string; password: string; email: string;};}){
let arr = dataForm.value.roles;
this.user.username = dataForm.value.username;
this.user.password = dataForm.value.password;
this.user.email = dataForm.value.email;
this.user.role.splice(0,1);
this.user.role.push(arr);

this.authSrv.signUp(this.user).subscribe(res =>{
  this.router.navigate(['/login'])
});}

signupForm(){
this.form = this.fb.group({
  username: new FormControl('', [Validators.required]),
  password: new FormControl('', [Validators.required]),
  email: new FormControl('', [Validators.required, Validators.email]),
  roles: new FormControl(),
});
this.form.controls['username'].setValue('');
this.form.controls['password'].setValue('');
}

getErrorsC(name: string, error: string) {
  return this.form.get(name)?.errors![error]
}
}
