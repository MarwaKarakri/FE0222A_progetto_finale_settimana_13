import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';



@Injectable({
  providedIn: 'root'
})
export class ClientiService {

  urlApi:string;
  constructor(private http: HttpClient) {
    this.urlApi = environment.urlApi;
  }

  get(c:number){
    return this.http.get<any>(this.urlApi + '/api/clienti?page=' + c + '&size=20&sort=id,ASC');
  }

  getById(id:number){
    return this.http.get<any>(this.urlApi + '/api/clienti/' + id);
  }

  getClienti(){
    return this.http.get<any>(this.urlApi + '/api/clienti/tipicliente');
  }

  delete(id:number){
    return this.http.delete<boolean>(this.urlApi+ '/api/clienti/' + id)
  }

  enregister(id: number, item: any){
    if (!id) {
			return this.http.post<any>(this.urlApi + '/api/clienti', item);
		} else {
			return this.http.put<any>(this.urlApi + '/api/clienti/' + id, item);
		}
  }
}
