import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FattureService {
  urlApi: string;

  constructor(private http: HttpClient) {
    this.urlApi = environment.urlApi;
  }

  get(f:number){
    return this.http.get<any>(this.urlApi + '/api/fatture?page=' + f + '&size=20&sort=id,ASC')
  }
  getById(id:number){
    return this.http.get<any>(this.urlApi + '/api/fatture/' + id);
  }

  getByClienti(id:number, c:number){
    return this.http.get<any>(this.urlApi + '/api/fatture/cliente/' + id +'?page=' + c + '&size=20&sort=id,ASC' );
  }

  delete(id:number){
    return this.http.delete<boolean>(this.urlApi+ '/api/fatture/' + id)
  }

  enregister(id: number, item: any){
    if (id === 0) {
			return this.http.post<any>(this.urlApi + '/api/fatture', item);
		} else {
			return this.http.put<any>(this.urlApi + '/api/fatture/' + id, item);
		}
  }



}
