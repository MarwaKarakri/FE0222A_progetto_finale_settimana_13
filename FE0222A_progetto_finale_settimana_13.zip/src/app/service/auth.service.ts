import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { JwtHelperService } from '@auth0/angular-jwt';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { User } from '../interface/user';

export interface AuthInfo{
  accessToken: string;
  user: {
    email: string;
    id: number;
    name: string;
  };
}

@Injectable({
  providedIn: 'root'
})

export class AuthService {
  private authSub = new BehaviorSubject<AuthInfo| null>(null);
  user$ = this.authSub.asObservable();
  jwthelper = new JwtHelperService();
  timeout: any;
  urlApi:string;
  constructor(private http: HttpClient, private router:Router) {
    this.urlApi = environment.urlApi;
   }

   get(u:number){
     return this.http.get<any>(this.urlApi + '/api/users?page=' + u + '&size=20&sort=id,ASC')
   }

   signUp(p:any){
     return this.http.post<any>(this.urlApi + '/api/auth/signup', p)
   }

   login(p: any) {
		return this.http.post<User>(this.urlApi + '/api/auth/login', p);
	}
	get isLogged(): boolean {
		return localStorage.getItem('utente') != null;
	}

  logout() {
    this.authSub.next(null);
    localStorage.removeItem('utente');
    this.router.navigate(['/login']);
    if (this.timeout) {
      clearTimeout(this.timeout);
    }
  }

}
