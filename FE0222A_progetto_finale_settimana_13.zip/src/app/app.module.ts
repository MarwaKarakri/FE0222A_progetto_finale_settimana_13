import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InterceptorInterceptor } from './interceptor/interceptor.interceptor';
import { LoginComponent } from './login/login.component';
import { DetailsClientiComponent } from './clienti/details_clienti/details-clienti.component';
import { ListaClientiComponent } from './clienti/lista-clienti/lista-clienti.component';
import { ListaComuniComponent } from './comuni/lista-comuni/lista-comuni.component';
import { DetailsFattureComponent } from './fatture/details-fatture/details-fatture.component';
import { DetailsComuniComponent } from './comuni/details-comuni/details-comuni.component';
import { ListaFattureComponent } from './fatture/lista-fatture/lista-fatture.component';
import { DetailsProvinceComponent } from './province/details-province/details-province.component';
import { ListaProvinceComponent } from './province/lista-province/lista-province.component';
import { SignupComponent } from './signup/signup.component';
import { DetailsStatoFatturaComponent } from './stato-fattura/details-stato-fattura/details-stato-fattura.component';
import { ListaStatoFatturaComponent } from './stato-fattura/lista-stato-fattura/lista-stato-fattura.component';
import { ListaComponent } from './user/lista.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DetailsClientiComponent,
    ListaClientiComponent,
    ListaComuniComponent,
    DetailsFattureComponent,
    DetailsComuniComponent,
    ListaFattureComponent,
    DetailsProvinceComponent,
    ListaProvinceComponent,
    SignupComponent,
    DetailsStatoFatturaComponent,
    ListaStatoFatturaComponent,
    ListaComponent,

  ],
  imports: [
    BrowserModule,
    NgbModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [{

    provide:HTTP_INTERCEPTORS,
    useClass: InterceptorInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
