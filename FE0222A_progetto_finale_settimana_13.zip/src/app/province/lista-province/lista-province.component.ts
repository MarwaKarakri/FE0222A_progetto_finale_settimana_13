import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-province',
  templateUrl: './lista-province.component.html',
  styleUrls: ['./lista-province.component.scss']
})
export class ListaProvinceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
