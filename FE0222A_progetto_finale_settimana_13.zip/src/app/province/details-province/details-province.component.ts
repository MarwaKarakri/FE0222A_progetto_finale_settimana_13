import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-province',
  templateUrl: './details-province.component.html',
  styleUrls: ['./details-province.component.scss']
})
export class DetailsProvinceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
