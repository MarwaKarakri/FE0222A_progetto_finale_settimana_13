import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './login/login.component';
import { ListaComponent } from './user/lista.component';
import { SignupComponent } from './signup/signup.component';
import { ListaClientiComponent } from './clienti/lista-clienti/lista-clienti.component';
import { DetailsClientiComponent } from './clienti/details_clienti/details-clienti.component';
import { ListaComuniComponent } from './comuni/lista-comuni/lista-comuni.component';
import { DetailsComuniComponent } from './comuni/details-comuni/details-comuni.component';
import { ListaProvinceComponent } from './province/lista-province/lista-province.component';
import { DetailsProvinceComponent } from './province/details-province/details-province.component';
import { ListaStatoFatturaComponent } from './stato-fattura/lista-stato-fattura/lista-stato-fattura.component';
import { DetailsStatoFatturaComponent } from './stato-fattura/details-stato-fattura/details-stato-fattura.component';
import { ListaFattureComponent } from './fatture/lista-fatture/lista-fatture.component';
import { DetailsFattureComponent } from './fatture/details-fatture/details-fatture.component';


const routes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'lista', component: ListaComponent, canActivate: [AuthGuard]},
  {path: 'signup', component: SignupComponent},
  {path: 'clienti', component: ListaClientiComponent, canActivate: [AuthGuard]},
  {path: 'clienti/:id', component: DetailsClientiComponent, canActivate: [AuthGuard]},
  {path: 'comuni', component: ListaComuniComponent, canActivate: [AuthGuard]},
  {path: 'comuni/:id', component: DetailsComuniComponent, canActivate: [AuthGuard]},
  {path: 'province', component: ListaProvinceComponent, canActivate: [AuthGuard]},
  {path: 'province/:id', component: DetailsProvinceComponent, canActivate: [AuthGuard]},
  {path: 'stato-fattura', component: ListaStatoFatturaComponent, canActivate: [AuthGuard]},
  {path: 'stato-fattura/:id', component: DetailsStatoFatturaComponent, canActivate: [AuthGuard]},
  {path: 'fatture', component: ListaFattureComponent, canActivate: [AuthGuard]},
  {path: 'fatture/cliente/:id', component: ListaFattureComponent, canActivate: [AuthGuard]},
  {path: 'fatture/:id', component: DetailsFattureComponent, canActivate: [AuthGuard]},
  {path: 'fatture/:id/:idCliente', component: DetailsFattureComponent, canActivate: [AuthGuard]},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
