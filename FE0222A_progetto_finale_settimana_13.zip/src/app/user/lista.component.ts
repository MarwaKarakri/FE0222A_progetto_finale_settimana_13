import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';
import { User } from '../interface/user';

@Component({
  selector: 'app-lista',
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.scss']
})
export class ListaComponent implements OnInit {
  users!: Array<User>;
  pageSize!:number;
  page!:number;
  response: any;
  constructor(private authSrv: AuthService, private router: Router, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.upload();
  }

  upload(){
    this.authSrv.get(0).subscribe(u=>{
      this.response = u;
      this.users = u.content;
    })
  }

  pageChanged(p:number) {
    this.authSrv.get(p).subscribe(c=>{
      this.response = c;
      this.users = c.content;
    })
  }

  counter(i:number){
    return new Array (i);
  }

  logout(){
    this.authSrv.logout()

  }
}
