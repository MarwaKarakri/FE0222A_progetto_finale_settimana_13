import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-stato-fattura',
  templateUrl: './lista-stato-fattura.component.html',
  styleUrls: ['./lista-stato-fattura.component.scss']
})
export class ListaStatoFatturaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
