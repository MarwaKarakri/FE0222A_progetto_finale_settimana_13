import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-stato-fattura',
  templateUrl: './details-stato-fattura.component.html',
  styleUrls: ['./details-stato-fattura.component.scss']
})
export class DetailsStatoFatturaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
