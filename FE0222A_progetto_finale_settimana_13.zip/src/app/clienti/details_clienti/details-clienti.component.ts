import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Cliente } from 'src/app/interface/cliente';
import { ClientiService } from 'src/app/service/clienti.service';
import { Comune } from 'src/app/interface/comune';
import { ComuniService } from 'src/app/service/comuni.service';
import { Provincia } from 'src/app/interface/provincia';
import { ProvinceService } from 'src/app/service/province.service';
import { AuthService } from 'src/app/service/auth.service';


@Component({
  selector: 'app-details-clienti',
  templateUrl: './details-clienti.component.html',
  styleUrls: ['./details-clienti.component.scss']
})
export class DetailsClientiComponent implements OnInit {

  id!: number;
	form!: FormGroup;
	cliente!: Cliente;
	province!: Provincia[];
	comuni!: Comune[];
	tipiclienti!: any[];

  constructor(private authSrv: AuthService,private clientiSrv: ClientiService, private comuniSrv: ComuniService, private provinceSrv: ProvinceService, private router: Router, private route: ActivatedRoute, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
			this.id = +params['id'];
			console.log(this.id);
			this.uploadForm();
			this.upload();
		});
  }

  clientiSave(dataForm:{value:{indirizzoSedeOperativa:{comune:Comune;};};}){
    this.comuni.forEach(item=>{
      if(item.id == dataForm.value.indirizzoSedeOperativa.comune.id){
        dataForm.value.indirizzoSedeOperativa.comune = item;
      }
    })
    this.clientiSrv.enregister(this.id, dataForm.value).subscribe(res=> {
      this.router.navigate(['/clienti']);
    })
  }

  uploadForm(){
    this.form  = this.fb.group({
      ragioneSociale: new FormControl('', [Validators.required]),
			partitaIva: new FormControl('', [Validators.required]),
			email: new FormControl('', [Validators.required]),
			tipoCliente: new FormControl('', [Validators.required]),
			pec: new FormControl(''),
			telefono: new FormControl(''),
			nomeContatto: new FormControl(''),
			cognomeContatto: new FormControl(''),
			telefonoContatto: new FormControl(''),
			emailContatto: new FormControl('', [Validators.required]),
			indirizzoSedeOperativa: this.fb.group({
				via: new FormControl(''),
				civico: new FormControl(''),
				cap: new FormControl(''),
				localita: new FormControl(''),
				comune: this.fb.group({
					id: new FormControl ('', Validators.required),
					nome: '',
					provincia: {}
				})
			})
    })
  }

  upload(){
    if (this.id !== 0) {
			this.clientiSrv.getById(this.id).subscribe(
				data => {
					console.log(data);
					this.cliente = data;
					this.form.patchValue({
						ragioneSociale: this.cliente.ragioneSociale,
						partitaIva: this.cliente.partitaIva,
						email: this.cliente.email,
						tipoCliente: this.cliente.tipoCliente,
						pec: this.cliente.pec,
						telefono: this.cliente.telefono,
						nomeContatto: this.cliente.nomeContatto,
						cognomeContatto: this.cliente.cognomeContatto,
						telefonoContatto: this.cliente.telefonoContatto,
						emailContatto: this.cliente.emailContatto,
						indirizzoSedeOperativa: {
							via: this.cliente.indirizzoSedeOperativa.via,
							civico: this.cliente.indirizzoSedeOperativa.civico,
							cap: this.cliente.indirizzoSedeOperativa.cap,
							localita: this.cliente.indirizzoSedeOperativa.localita
						},
					})
				}
			)
		}
		this.clientiSrv.getClienti().subscribe(res => this.tipiclienti = res);
    this.comuniSrv.get(0).subscribe(res => this.comuni = res.content);
    this.provinceSrv.get(0).subscribe(res => this.province = res.content);
  }

  logout(){
    this.authSrv.logout()

  }

}
