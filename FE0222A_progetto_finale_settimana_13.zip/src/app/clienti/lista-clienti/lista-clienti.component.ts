import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup} from '@angular/forms';
import { Cliente } from 'src/app/interface/cliente';
import { ClientiService } from 'src/app/service/clienti.service';
import { AuthService } from 'src/app/service/auth.service';


@Component({
  selector: 'app-lista-clienti',
  templateUrl: './lista-clienti.component.html',
  styleUrls: ['./lista-clienti.component.scss']
})
export class ListaClientiComponent implements OnInit {
	form!: FormGroup;
	page!: number;
	pageSize!: number;
	response: any;
	clienti!: Cliente[];
  constructor(private clientSrv: ClientiService, private route: Router, private fb: FormBuilder, private authSrv: AuthService) { }

  ngOnInit(): void {
    this.upload();
    this.uploadForm();
  }
  counter(i: number) {
		return new Array(i);
	}

  upload(){
    this.clientSrv.get(0).subscribe(c=>{
      this.response = c;
      this.clienti = c.content;
    })
  }

  uploadForm(){
    this.form = this.fb.group({
      search: new FormControl()
    });
  }

  changePage(p:number){
this.clientSrv.get(p).subscribe(c=>{
  this.response = c;
  this.clienti = c.content;
})
  }


  Ondelete(name: string, id: number, i:number){
    this.clientSrv.delete(id).subscribe(d => {
      this.clienti.splice(i,1)
    })
  }
  logout(){
    this.authSrv.logout()

  }
}
