import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-comuni',
  templateUrl: './details-comuni.component.html',
  styleUrls: ['./details-comuni.component.scss']
})
export class DetailsComuniComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
