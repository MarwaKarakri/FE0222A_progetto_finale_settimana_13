import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-comuni',
  templateUrl: './lista-comuni.component.html',
  styleUrls: ['./lista-comuni.component.scss']
})
export class ListaComuniComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
