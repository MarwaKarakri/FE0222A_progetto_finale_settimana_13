import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';
import { User } from 'src/app/interface/user';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
user!: User;
item: any;
form!: FormGroup;
  constructor(private authSrv: AuthService, private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
		this.formLogin();
	}

  client(dataForm:{value:any;}){
    this.item = dataForm.value;
    this.authSrv.login(this.item).subscribe(res => {
      this.user = res;
      localStorage.setItem('utente', JSON.stringify(this.user));
      this.router.navigate(["/lista"]);
    });
  }

  formLogin() {
		this.form = this.fb.group({
			username: new FormControl('', [Validators.required]),
			password: new FormControl('', [Validators.required])
		});
		this.form.controls['username'].setValue('');
		this.form.controls['password'].setValue('');
	}


}
