import { Component } from '@angular/core';
import { AuthService } from './service/auth.service';
import { User } from './interface/user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'FE0222A_progetto_finale_settimana_13';


  constructor(private authSrv:AuthService) {}


  ngOnInit(): void {
  }

  logout(){
    this.authSrv.logout()
  }

}
